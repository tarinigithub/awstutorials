var DEBUG = true;
function LOG(s) {
    if (window && window.console) {
        var now = new Date().toISOString();
        window.console.log('%c' + now + ' S4GA::AUTH: ' + s, 'background: #FFFFFF; color: #FF4500');
    }
}
//# sourceMappingURL=Shared.js.map