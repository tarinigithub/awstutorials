// Our own extension ID.
var extn_id = chrome.runtime.id;
DEBUG && LOG('ChromePhoneBackground.ts ==========> ShoreTel for Google Apps Background Auth Page, Extension ID = ' + extn_id);
// ShoreTel object for communicating with ShoreTel side of extension.
var stComm = new ShoreTel('GoogleApps', extn_id);
// Try to refresh token if less than this many minutes remaining to expiry
var TOKEN_REFRESH_MINUTES_LEFT = 10;
// The current token and expiration
var authToken = null;
var authExpiration = new Date().getTime();
// Handle subscribers to token.
var tokenChanger = $.Callbacks('unique memory');
// Keep track of Gapi authorization page 1 iframe. We create and destroy as needed.
var iFrame = null;
var iFrameTS = null;
// This is a user ID (email) override.  Used if the Google user must be different than their ShoreTel user ID.
// NOTE: Make this empty if ShoreTel username is expected to be equal to Google username (the expected case)
// this override is only for test purposes.
var EMAIL = null;
// Listen for and process events from Gapi Auth pages.
chrome.runtime.onMessageExternal.addListener(function (msg, sender, sendResponse) {
    DEBUG && LOG('onMessageExternal(), External Message, URL = ' + sender.url);
    if (msg) {
        var authMsg = msg;
        // Break out by message.
        switch (authMsg.msgType) {
            // Auth page wants to know our ShoreTel username. Send it.
            case 0 /* eAM_STInfoRequest */:
                var userNameResp = null;
                // If the override is set, send it instead.
                if (EMAIL) {
                    userNameResp = EMAIL;
                }
                else {
                    userNameResp = stComm ? stComm.username : null;
                }
                DEBUG && LOG('onMessageExternal(), STInfoRequest, Returning username = ' + userNameResp);
                if (sendResponse) {
                    sendResponse(userNameResp);
                }
                break;
            // Auth page is giving us the results. Process.
            case 1 /* eAM_AuthResult */:
                var authResult = authMsg.authResult;
                // No matter what, if this was from page 1 (the iFrame we created), we need to get rid of it.
                if (authResult.pageNr == 1) {
                    RemoveAuthPage1Frame(true);
                }
                if (authResult.error) {
                    // FAILURE, no token obtained.
                    DEBUG && LOG('onMessageExternal(), AuthResult, Error = ' + authResult.error + ', Page = ' + authResult.pageNr);
                    // Map all errors to either generic or "user mismatch".
                    var ats = 2 /* eATS_NoToken */;
                    // If "user mismatch", we wrongly acquired a token for a different user. Need to reverse.
                    if (authResult.error == 'user_mismatch') {
                        ats = 1 /* eATS_UserMismatch */;
                        // Need to undo authorization, wrongly accepted.
                        RevokeAuthorization(authResult.token);
                    }
                    // Indicate no token.
                    SetNewToken(null, 0, ats);
                }
                else if (authResult.token) {
                    // SUCCESS, we have a good token.
                    DEBUG && LOG('onMessageExternal(), AuthResult, Token Success, Page = ' + authResult.pageNr);
                    // But could've seen a log out since the auth started.  Re-test for logged in.
                    if (ShoreTelLoggedIn) {
                        // Indicate good token.
                        SetNewToken(authResult.token, authResult.expires, 0 /* eATS_Valid */);
                    }
                    else {
                        // No longer logged in.  Doesn't matter if auth token was issued.
                        SetNewToken(null, 0, 2 /* eATS_NoToken */);
                    }
                }
                break;
        }
    }
});
// Allow ShoreTel side to trigger the Gapi authorization 2 page. This is the only way that page is shown.
if (stComm)
    stComm.onauthorize = function () {
        chrome.tabs.create({ url: chrome.i18n.getMessage('GA2_URL') + '?ExtnID=' + extn_id });
    };
// ShoreTel side will trigger changes to "ShoreTel Ready".
// Ready is defined by the core extension as loggedIn (ABC) and connected (CAS).
// We are only interested in loggedIn.
var ShoreTelLoggedIn = false;
if (stComm)
    stComm.onready = function (loggedIn, connected) {
        DEBUG && LOG('Received onready() from core, loggedIn = ' + loggedIn + ', connected = ' + connected);
        // If there has been a change in loggedIn, need to run our test now.
        if (loggedIn != ShoreTelLoggedIn) {
            ShoreTelLoggedIn = loggedIn;
            RunTestCheckAuth(0);
        }
    };
// The token starts out null. Tell all subscribers.
tokenChanger.fire(null);
// In case reason for no token changes...remember last one we saw.
//var atsLastSent: AuthTokenStatus = AuthTokenStatus.eATS_NoToken;
// And tell ShoreTel side of extension of initial state.
if (stComm)
    stComm.propertyChanged('AuthToken', 2 /* eATS_NoToken */);
// Take a breath...and go.
RunTestCheckAuth(2000);
// ==============> Functions or constants ONLY after this.
// Time to next test for ShoreTel ready and auth token validation/refresh
// Do not set any greater than 5 minutes (300000ms).
// Note it could run before this based on event receipt in code above...see calls to RunTestCheckAuth().
var NEXT_TEST_NORMAL_MS = 180000; // 3 minutes.
function TestCheckAuth() {
    var stUserName = (EMAIL) ? EMAIL : (stComm ? stComm.username : null);
    DEBUG && LOG('TestCheckAuth(), ShoreTel LoggedIn = ' + ShoreTelLoggedIn + (ShoreTelLoggedIn ? (', ST User = ' + stUserName) : ""));
    var nextMS = NEXT_TEST_NORMAL_MS;
    if (ShoreTelLoggedIn) {
        // User is logged into ShoreTel. See if time for new token.
        if (IsNewTokenNeeded()) {
            // Either no token or time to refresh. Create auth frame if possible.
            if (TestCreateAuthPage1Frame()) {
                // Need auth frame but one already recently created. Let it do its thing.
                nextMS = FRAME_MIN_BUSY_MS;
            }
        }
    }
    else {
        SetNewToken(null, 0, 2 /* eATS_NoToken */);
    }
    // If nothing else happens to change this, we'll schedule to return in a while.
    RunTestCheckAuth(nextMS);
}
// Someone may want to run TestCheckAuth() sooner.
var TestCheckAuthTimeoutID = 0;
function RunTestCheckAuth(FutureMS) {
    DEBUG && LOG('RunTestCheckAuth(), Setting to run in ' + FutureMS + 'ms');
    // Clear current scheduled time.
    if (TestCheckAuthTimeoutID > 0) {
        clearTimeout(TestCheckAuthTimeoutID);
    }
    // Schedule to run as indicated.
    TestCheckAuthTimeoutID = setTimeout(TestCheckAuth, FutureMS);
}
// Try to create Gapi authorization page 1 which is held in an invisible iFrame.
// It will run (hopefully) and return results via external chrome message. When we
// get the message, we'll remove the iFrame.
var FRAME_MIN_BUSY_MS = 10000;
function TestCreateAuthPage1Frame() {
    var stillBusy = false;
    // Just in case. Only ever one and let each one run at least some minimum time.
    if (TestFrameStillBusy()) {
        DEBUG && LOG('CreateAuthPage1Frame(), iFrame still busy, TS = ' + PrintTS(iFrameTS));
        stillBusy = true;
    }
    else {
        RemoveAuthPage1Frame(false);
        if (document && document.body) {
            iFrame = document.createElement("IFRAME");
            iFrame.height = '0';
            iFrame.width = '0';
            iFrame.id = "GapiIframe";
            iFrame.scrolling = "no";
            iFrame.style.margin = "0px";
            iFrame.style.padding = "0px";
            iFrame.style.visibility = "hidden";
            iFrame.style.position = "absolute";
            iFrame.style.top = "0";
            iFrame.style.left = "0";
            iFrame.style.zIndex = "100";
            iFrame.src = chrome.i18n.getMessage('GA1_URL') + '?ExtnID=' + extn_id;
            iFrameTS = new Date();
            DEBUG && LOG('CreateAuthPage1Frame(), Creating Frame, TS = ' + PrintTS(iFrameTS));
            document.body.appendChild(iFrame);
        }
    }
    return (stillBusy);
}
function TestFrameStillBusy() {
    var stillBusy = false;
    if (iFrame && iFrameTS) {
        var now = new Date().getTime();
        var frameCreated = iFrameTS.getTime();
        if ((now - frameCreated) < (FRAME_MIN_BUSY_MS - 500)) {
            stillBusy = true;
        }
    }
    return (stillBusy);
}
function RemoveAuthPage1Frame(normallyExpected) {
    if (iFrame && document && document.body) {
        DEBUG && LOG('RemoveFrame(), TS = ' + PrintTS(iFrameTS) + ', Expected = ' + normallyExpected);
        document.body.removeChild(iFrame);
    }
    iFrame = null;
    iFrameTS = null;
}
function PrintTS(ts) {
    var s = '';
    if (ts) {
        s = ts.getHours().toString() + ':' + ts.getMinutes().toString() + ':' + ts.getSeconds().toString() + '.' + ts.getMilliseconds().toString();
    }
    return (s);
}
function SetNewToken(newToken, expiresSeconds, ats) {
    // Fire token change, but no need when was and is still null.
    if (authToken || newToken) {
        // Either current or new is not null. Set new value and fire.
        authToken = newToken;
        authExpiration = new Date().getTime() + (expiresSeconds * 1000);
        DEBUG && LOG('SetNewToken(), Token now = ' + authToken + ', Expiration = ' + new Date(authExpiration).toTimeString());
        // Tell everyone.
        tokenChanger.fire(authToken);
    }
    DEBUG && LOG('SetNewToken(), Sending to core, propertyChanged, AuthToken = ' + ats);
    if (stComm)
        stComm.propertyChanged('AuthToken', ats);
}
function SubscribeTokenChange(cb) {
    tokenChanger.add(cb);
}
function UnSubscribeTokenChange(cb) {
    tokenChanger.remove(cb);
}
function TokenNearExpiry() {
    var now = new Date().getTime();
    return (!authExpiration || (((authExpiration - now) / 60000) < TOKEN_REFRESH_MINUTES_LEFT));
}
function IsNewTokenNeeded() {
    var rc = false;
    rc = (!authToken || TokenNearExpiry());
    var expStr = authToken ? new Date(authExpiration).toTimeString() : null;
    DEBUG && LOG('IsNewTokenNeeded(), Current Token = ' + authToken + ', Expiration = ' + expStr + ', Returning IsNewTokenNeeded = ' + rc);
    return (rc);
}
function RevokeAuthorization(token) {
    if (token) {
        DEBUG && LOG('RevokeAuthorization(), Token = ' + token);
        $.ajax('https://accounts.google.com/o/oauth2/revoke?token=' + token)
            .done(function (data) {
            DEBUG && LOG('ChromePhoneBackground::RevokeAuthorization(), Success, data = ' + data);
        })
            .fail(function (jqXHR, textStatus, error) {
            DEBUG && LOG('ChromePhoneBackground::RevokeAuthorization(), Failure, error = ' + error);
        });
    }
}
//# sourceMappingURL=ChromePhoneBackground.js.map