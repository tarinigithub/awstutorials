//import {IConference} from 'shoretel-objects/objects';
var ShoreTel = (function () {
    /**
     * @description Creates an instance of the ShoreTel class.
     * @param {string} appName - A user-friendly name for the app.
     * @param {string} extensionId? - The chrome ID of the extension running CAS. Leave
     * this blank if this script is already running in that context.
     */
    function ShoreTel(appName, extensionId, runningInBackground) {
        if (runningInBackground === void 0) { runningInBackground = true; }
        this.connected = false;
        this.failover = false;
        // State management
        this.name = "";
        this.username = "";
        this.isAuthenticated = false;
        this.isLoggedIn = false;
        this.isConnected = false;
        this.isUCBEnabled = false;
        this.dialingLocation = -1;
        this.autoCHM = false;
        this.chmSourceOurs = false;
        // Arrays
        this.conferences = new Map();
        this.observables = [];
        if (window[ShoreTel.GLOBAL_VARIABLE] == undefined)
            window[ShoreTel.GLOBAL_VARIABLE] = {};
        if (window[ShoreTel.GLOBAL_VARIABLE]['onMessage'] == undefined)
            window[ShoreTel.GLOBAL_VARIABLE]['onMessage'] = [];
        if (window[ShoreTel.GLOBAL_VARIABLE]['callbacks'] == undefined)
            window[ShoreTel.GLOBAL_VARIABLE]['callbacks'] = {};
        if (runningInBackground) {
            this.failover = true;
            // Set up callbacks
            window[ShoreTel.GLOBAL_VARIABLE]['onMessage'].push(this.chromeMessageHandler.bind(this));
        }
        else if (extensionId != undefined) {
            this.port = chrome.runtime.connect(extensionId);
            // Set up callbacks
            this.port.onMessage.addListener(this.chromeMessageHandler.bind(this));
        }
        else {
            this.port = chrome.runtime.connect();
            // Set up callbacks
            this.port.onMessage.addListener(this.chromeMessageHandler.bind(this));
        }
        // Handshake
        try {
            this.chromeSendMessage('hello', appName, { 'version': ShoreTel.VERSION });
            // Subscribe to conferences
            this.chromeSendMessage('observable', 'conferences');
        }
        catch (err) {
            console.error(err);
        }
    }
    ShoreTel.prototype.propertyChanged = function (name, value) {
        this.chromeSendMessage('custom', name, { 'value': value });
    };
    ShoreTel.prototype.chromeSendMessage = function (type, name, params) {
        var message = {
            'type': type,
            'name': name
        };
        if (params != undefined)
            for (var _i = 0, _a = Object.keys(params); _i < _a.length; _i++) {
                var key = _a[_i];
                message[key] = params[key];
            }
        if (this.failover) {
            if (typeof window[ShoreTel.GLOBAL_VARIABLE]['sendMessage'] == 'function') {
                window[ShoreTel.GLOBAL_VARIABLE]['sendMessage'](message);
            }
        }
        else {
            this.port.postMessage(message);
        }
    };
    ShoreTel.prototype.chromeMessageHandler = function (message) {
        switch (message['type']) {
            case 'init':
                this.chromeInitHandler(message);
                break;
            case 'property':
                this.chromePropertyHandler(message);
                break;
            case 'observable':
                this.chromeObservableHandler(message);
                break;
            case 'event':
                this.chromeEventHandler(message);
                break;
            default:
                console.warn('Unknown message from client.', message);
                break;
        }
    };
    ShoreTel.prototype.chromeInitHandler = function (message) {
        var _this = this;
        console.log('Init handler', message);
        this.isAuthenticated = message['state']['isAuthenticated'];
        this.isLoggedIn = message['state']['isLoggedIn'];
        this.isConnected = message['state']['isConnected'];
        this.isUCBEnabled = message['state']['isUCBEnabled'];
        this.name = message['name'];
        this.username = message['username'];
        this.dialingLocation = message['dialingLocation'];
        this.conferences.clear();
        message['conferences'].forEach(function (conference) { return _this.conferences.set(conference['id'], conference); });
        if (typeof this.onready == 'function')
            this.onready(this.isLoggedIn, this.isConnected, this.isUCBEnabled);
    };
    ShoreTel.prototype.chromePropertyHandler = function (message) {
        var _this = this;
        console.log('Property handler', message);
        switch (message['name']) {
            case 'state':
                var oldLoggedIn = this.isLoggedIn;
                var oldConnected = this.isConnected;
                var oldUCB = this.isUCBEnabled;
                this.isAuthenticated = message['value']['isAuthenticated'];
                this.isLoggedIn = message['value']['isLoggedIn'];
                this.isConnected = message['value']['isConnected'];
                this.isUCBEnabled = message['value']['isUCBEnabled'];
                // These are readable and kept up to date but no event on their change.
                this.autoCHM = message['value']['autoCHM'];
                this.chmSourceOurs = message['value']['chmSourceOurs'];
                // Only send an update if one of the fields we care about changed
                if (typeof this.onready == 'function' &&
                    (this.isLoggedIn != oldLoggedIn || this.isConnected != oldConnected || this.isUCBEnabled != oldUCB))
                    this.onready(this.isLoggedIn, this.isConnected, this.isUCBEnabled);
                break;
            case 'name':
                this.name = message['value'];
                break;
            case 'username':
                this.username = message['value'];
                break;
            case 'dialingLocation':
                this.dialingLocation = message['value'];
                break;
            case 'conferences':
                this.conferences.clear();
                message['value'].forEach(function (conference) { return _this.conferences.set(conference['id'], conference); });
                break;
        }
    };
    ShoreTel.prototype.chromeObservableHandler = function (message) {
        //console.log('Observable handler', message);
        if (!this.observables.some(function (obs) { return obs == message['name']; })) {
            //console.debug("Ignoring observable " + message['name']);
            return;
        }
        // Find the callbacks
        var callbacks = null;
        if (window[ShoreTel.GLOBAL_VARIABLE]['callbacks'].hasOwnProperty(message['name']))
            callbacks = window[ShoreTel.GLOBAL_VARIABLE]['callbacks'][message['name']];
        if (callbacks == null) {
            console.warn('Received an update but have no matching callbacks.', message['name']);
            return;
        }
        // Handle error and end cases
        if (message['state'] == 'error') {
            if (typeof callbacks['failure'] === 'function')
                callbacks['failure'](message['value']);
            return;
        }
        else if (message['state'] == 'end') {
            delete window[ShoreTel.GLOBAL_VARIABLE]['callbacks'][message['name']];
            this.observables = this.observables.filter(function (obs) { return obs != message['name']; });
            console.log('Observable completed.', message['name']);
            return;
        }
        // Send update
        if (typeof callbacks['success'] === 'function')
            callbacks['success'](message['value']);
    };
    ShoreTel.prototype.chromeEventHandler = function (message) {
        console.log('Event handler', message);
        switch (message['name']) {
            case 'onauthorize':
                if (typeof this.onauthorize == 'function')
                    this.onauthorize();
                break;
            case 'oncontactsearch':
                var reply = {
                    'type': 'event',
                    'name': 'oncontactsearch',
                    'id': message['id'],
                    result: []
                };
                if (typeof this.oncontactsearch == 'function') {
                    this.oncontactsearch(message['query'], message['count'], function (results) {
                        reply.result = results;
                        if (this.failover)
                            if (typeof window[ShoreTel.GLOBAL_VARIABLE]['sendMessage'] == 'function')
                                window[ShoreTel.GLOBAL_VARIABLE]['sendMessage'](reply);
                            else
                                this.port.postMessage(reply);
                    }.bind(this));
                }
                else {
                    if (this.failover)
                        if (typeof window[ShoreTel.GLOBAL_VARIABLE]['sendMessage'] == 'function')
                            window[ShoreTel.GLOBAL_VARIABLE]['sendMessage'](reply);
                        else
                            this.port.postMessage(reply);
                }
                break;
            default:
                break;
        }
    };
    ShoreTel.prototype.registerCallback = function (name, successCallback, failureCallback) {
        var id = name + '/' + (new Date().getTime() + Math.random()).toString();
        this.observables.push(id);
        window[ShoreTel.GLOBAL_VARIABLE]['callbacks'][id] = {
            'success': successCallback,
            'failure': failureCallback
        };
        return id;
    };
    /**
     * @description Checks that the library is ready to be used.
     * @return {boolean} If false, attempts to use this library will fail.
     */
    ShoreTel.prototype.isReady = function () {
        return this.isLoggedIn && this.isConnected;
    };
    /**
     * @description Places a call to the supplied phone number.
     * @param {string} tn - The number to place a phone call to.
     */
    ShoreTel.prototype.tel_makeCall = function (tn) {
        this.chromeSendMessage('function', 'tel_makeCall', { 'tn': tn });
    };
    ShoreTel.prototype.conf_createMeeting = function (createMeetingArgs, successCallback, failureCallback) {
        var messageName = "conf_createMeeting";
        // Register callbacks
        var id = this.registerCallback(messageName, successCallback, failureCallback);
        // Send message
        this.chromeSendMessage('observable', messageName, {
            'id': id,
            'params': [createMeetingArgs == null ? undefined : createMeetingArgs]
        });
    };
    ShoreTel.prototype.conf_updateMeeting = function (updateMeetingArgs, successCallback, failureCallback) {
        var messageName = "conf_updateMeeting";
        // Register callbacks
        var id = this.registerCallback(messageName, successCallback, failureCallback);
        // Send message
        this.chromeSendMessage('observable', messageName, {
            'id': id,
            'params': [updateMeetingArgs]
        });
    };
    ShoreTel.prototype.conf_deleteMeeting = function (meetingID, successCallback, failureCallback) {
        var messageName = "conf_deleteMeeting";
        // Register callbacks
        var id = this.registerCallback(messageName, successCallback, failureCallback);
        // Send message
        this.chromeSendMessage('observable', messageName, {
            'id': id,
            'params': [meetingID]
        });
    };
    ShoreTel.prototype.conf_getMeeting = function (meetingID, successCallback, failureCallback) {
        var messageName = "conf_getMeeting";
        // Register callbacks
        var id = this.registerCallback(messageName, successCallback, failureCallback);
        // Send message
        this.chromeSendMessage('observable', messageName, {
            'id': id,
            'params': [meetingID]
        });
    };
    ShoreTel.prototype.conf_dialIntoMeeting = function (meetingID, phoneNumber, successCallback, failureCallback) {
        var messageName = "conf_dialIntoMeeting";
        // Register callbacks
        var id = this.registerCallback(messageName, successCallback, failureCallback);
        // Send message
        this.chromeSendMessage('observable', messageName, {
            'id': id,
            'params': [meetingID, phoneNumber]
            //'confId': meetingID, //UCB meeting ID
            //'phoneNumber': phoneNumber //It is the number to call; for calling the user’s ShoreTel extension leave it blank but, otherwise, it needs to be provided
        });
    };
    ShoreTel.prototype.chm_upload = function (source, timezone, entries, successCallback, failureCallback) {
        var messageName = "chm_upload";
        // Register callbacks
        var id = this.registerCallback(messageName, successCallback, failureCallback);
        // Send message
        this.chromeSendMessage('observable', messageName, {
            'id': id,
            'params': [source, timezone, entries]
        });
    };
    return ShoreTel;
}());
ShoreTel.GLOBAL_VARIABLE = "shoreteljs_failover";
ShoreTel.VERSION = 5.00;
//# sourceMappingURL=shoretel.js.map