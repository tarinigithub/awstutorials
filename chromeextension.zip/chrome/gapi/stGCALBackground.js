//import { ConferenceEnums } from '../shoretel-objects/src/enumerations';
DEBUG && LOG('stGCALBackground.ts ==========> Google Calendar Background Page');
var extn_id = chrome.runtime.id;
var stComm = new ShoreTel('GoogleApps', extn_id);
// We cache all user's GCAL events
var GCalEvents = new Map();
// Backoff refresh time scheme.
var MAX_REFRESH_BACKOFF_HIGH_INDEX = 4;
var refreshBackOffCurrentIndex = 0;
var RefreshBackOffSeconds = [300, 150, 30, 10, 3];
function GetNormalRefreshTime() {
    var refreshTime = RefreshBackOffSeconds[0];
    if ((refreshBackOffCurrentIndex > 0) && (refreshBackOffCurrentIndex <= MAX_REFRESH_BACKOFF_HIGH_INDEX)) {
        refreshTime = RefreshBackOffSeconds[refreshBackOffCurrentIndex];
        refreshBackOffCurrentIndex--;
    }
    return (refreshTime * 1000);
}
// Special purpose refresh times, MILLISECONDS.
var GCAL_INITIAL_REFRESH_BACKOFF_TIME = 3000;
var GCAL_IMMEDIATE_REFRESH_TIME = 80;
var GCAL_SHORT_REFRESH_TIME = 500;
var GCAL_ERROR_REFRESH_TIME = 180000;
var NOTIFICATION_DURATION_MS = 9000;
// Events API, See: https://developers.google.com/google-apps/calendar/v3/reference/events/list
var GCAL_EVENTS_REQUEST = 'https://www.googleapis.com/calendar/v3/calendars/primary/events';
// Return at most this many events per "page".
var GCAL_EVENTS_MAXRESULTS = 100;
// Get events created/udpated up to this many days ago.
var GCAL_EVENTS_SINCE_DAYS_AGO = 7;
var GCAL_EVENTS_SINCE_MS_AGO = GCAL_EVENTS_SINCE_DAYS_AGO * 24 * 60 * 60 * 1000; // Change above, not this.
// Free/Busy API, See: https://developers.google.com/google-apps/calendar/v3/reference/freebusy/query
var GCAL_FREEBUSY_REQUEST = 'https://www.googleapis.com/calendar/v3/freeBusy';
// Free/Busy query date/time range.
var GCAL_FREEBUSY_SINCE_DAYS_AGO = 0;
var GCAL_FREEBUSY_SINCE_MS_AGO = GCAL_FREEBUSY_SINCE_DAYS_AGO * 24 * 60 * 60 * 1000; // Change above, not this.
var GCAL_FREEBUSY_DAYS_FROM_NOW = 15;
var GCAL_FREEBUSY_MS_FROM_NOW = GCAL_FREEBUSY_DAYS_FROM_NOW * 24 * 60 * 60 * 1000; // Change above, not this.
// Normally, wake up every this many minutes to see if time to refresh free/busy list.
var GCAL_FREEBUSY_PROCESS_TIME_MINUTES = 2;
var GCAL_FREEBUSY_PROCESS_TIME_MS = GCAL_FREEBUSY_PROCESS_TIME_MINUTES * 60 * 1000; // Change above, not this.
var GCAL_FREEBUSY_PROCESS_TIME_INITIAL_MS = 20 * 1000; // Exception: Run first time shortly after we start running.
// Max time of countinous running before we do free/busy update anyway.
var GCAL_FREEBUSY_MAX_HOURS_UPDATE = 24;
var GCAL_FREEBUSY_MAX_MS_UPDATE = GCAL_FREEBUSY_MAX_HOURS_UPDATE * 60 * 60 * 1000; // Change above, not this.
var TabMessages = new Map();
// This listener is to help our content script identify a change in URL.
// If we see a completed page and it matches the calendar URL, send message to that tab.
chrome.tabs.onUpdated.addListener(function (tabId, changeInfo, tab) {
    if (changeInfo && changeInfo.status && tab && tab.url) {
        //DEBUG && LOG('GCAL tabs.onUpdated(), tabID = ' + tabId + ', changeInfo = ' + JSON.stringify(changeInfo) + ', tab = ' + JSON.stringify(tab));
        if (changeInfo.status == 'complete' && tab.url.includes('.google.com/calendar/r')) {
            DEBUG && LOG('GCAL tabs.onUpdated(), Sending GCALNewURL message to tabID = ' + tabId);
            chrome.tabs.sendMessage(tabId, { Target: 'GCALNewURL' });
        }
    }
});
// Listen for requests for GCAL objects.
chrome.runtime.onMessage.addListener(function (req, sender, sendResponse) {
    if (req && req.Target && (req.Target == 'GCAL') && req.Command) {
        DEBUG && LOG('GCAL Message Listener, Sender = ' + JSON.stringify(sender));
        DEBUG && LOG('GCAL Message Listener, Request = ' + JSON.stringify(req));
        // Handle commands with no response first.
        if (req.Command == 'GCALSaved') {
            // Special case. Content is telling us an event was saved. Speed up our process temporarily.
            // No response is sent to this request.
            // Begin backoff countdown.
            refreshBackOffCurrentIndex = MAX_REFRESH_BACKOFF_HIGH_INDEX;
            ScheduleGCalProcess(GCAL_INITIAL_REFRESH_BACKOFF_TIME);
        }
        else {
            // Assume "Not Found" response.
            var resp = {};
            resp['Result'] = 'Not Found';
            // See if username matches.  Return username in any case but only if logged in.
            resp['UserBG'] = stComm.isLoggedIn ? stComm.username : '';
            // Also return what was sent.
            if (req.UserFG)
                resp['UserFG'] = req.UserFG;
            if (req.PCode)
                resp['PCode'] = req.PCode;
            // However, if username does not match, do not return any tokens or events.
            if (req.UserFG && stComm.isLoggedIn && stComm.username && (req.UserFG == stComm.username)) {
                switch (req.Command) {
                    // Search by participant code
                    case 'GCALByPCode': {
                        // If an existing tab asks again, forget what they asked earlier.
                        if (TabMessages.has(sender.tab.id)) {
                            TabMessages.delete(sender.tab.id);
                        }
                        if (req.PCode) {
                            // Untangle.
                            var pCode = req.PCode;
                            DEBUG && LOG('GCAL Message Listener, PCode = ' + pCode);
                            if (pCode && (pCode != 'None')) {
                                // Participant code is given...we should find it.
                                var foundEvent = GCALSearchPCode(pCode);
                                if (foundEvent) {
                                    // Found matching participant code.
                                    resp['Result'] = 'Found';
                                    resp['GCALEvent'] = foundEvent;
                                }
                                else {
                                    // Not there.  We'll do a sweep soon and tell them later.
                                    resp['Result'] = 'Not Found Yet';
                                    // Make note of who asked us, id and pCode.
                                    TabMessages.set(sender.tab.id, { id: sender.tab.id, pCode: pCode });
                                    // Cause run of GCAL process now.
                                    ScheduleGCalProcess(GCAL_IMMEDIATE_REFRESH_TIME);
                                }
                            }
                        }
                        break;
                    }
                    // Return GCAL token.
                    case 'GCALToken': {
                        if (CurrentToken) {
                            resp['Result'] = 'Found';
                            resp['Token'] = CurrentToken;
                        }
                        break;
                    }
                }
            }
            DEBUG && LOG('GCAL Message Listener, Response = ' + JSON.stringify(resp));
            sendResponse(resp);
        }
    }
});
function GCALSearchPCode(pCode) {
    var e = null;
    for (var _i = 0, _a = Array.from(GCalEvents); _i < _a.length; _i++) {
        var _b = _a[_i], k = _b[0], v = _b[1];
        if (v.extendedProperties &&
            v.extendedProperties.shared &&
            v.extendedProperties.shared['ShoreTelUCBPCode'] &&
            (v.extendedProperties.shared['ShoreTelUCBPCode'] == pCode)) {
            // Found matching participant code.
            e = v;
            break;
        }
    }
    return (e);
}
// We need the OAuth token, and we need to keep it up to date.
window['SubscribeTokenChange'](GCalTokenChange);
// Wake up regularly to see if time to update free/busy list. The free/busy list is used to
// set AutoCHM schedule for ShoreTel user.
var FBLastUpdate = new Date(0); // Date/Time we last updated.
var FBNeedUpdate = true; // Always needs update initially.
var AutoCHMWasOn = false; // Assume off at first.
// Test for free/busy update...first time in just a few seconds...longer thereafter.
setTimeout(GCalTestFreeBusy, GCAL_FREEBUSY_PROCESS_TIME_INITIAL_MS);
function GCalTestFreeBusy() {
    try {
        // Test for case of AutoCHM having been turned on when it was off before. We should update FB now, if so.
        if (!AutoCHMWasOn) {
            if (stComm.autoCHM && stComm.chmSourceOurs) {
                FBNeedUpdate = true; // So we'll update below.
            }
        }
        AutoCHMWasOn = (stComm.autoCHM && stComm.chmSourceOurs); // Always set this to current value for next time around.
        // We'll read the free/busy list and update ShoreTel if the "need update" flag is set or
        // if it has been a long time continuously running since any update.  The flag will be set
        // when calendar changes are detected or when we've logged out and in again, etc.
        if (FBNeedUpdate || (this.FBMSSinceLastUpdate() > GCAL_FREEBUSY_MAX_MS_UPDATE)) {
            // Time for an update now.
            // Clear this flag.  We'll reset it if the update fails.
            FBNeedUpdate = false;
            // Start the update process.
            GCalQueryFreeBusy();
        }
    }
    catch (ex) {
        DEBUG && LOG('GCalTestFreeBusy(), Exception = ' + ex);
    }
    // Rinse, lather, repeat.
    setTimeout(GCalTestFreeBusy, GCAL_FREEBUSY_PROCESS_TIME_MS);
}
function FBMSSinceLastUpdate() {
    var tNow = Date.now();
    var tThen = FBLastUpdate.getTime();
    return (tNow - tThen);
}
// This holds current Google OAUTH token.
var CurrentToken = null;
var GCalTimeoutID = 0;
function GCalTokenChange(newToken) {
    DEBUG && LOG('GCalTokenChange(), New Token = ' + newToken + ', Current Token = ' + CurrentToken);
    // If token was null and now is not null, schedule a cache refresh soon as well as a free/busy update process.
    if (!CurrentToken && newToken) {
        ScheduleGCalProcess(GCAL_SHORT_REFRESH_TIME);
        FBNeedUpdate = true;
    }
    // If new token is null, clear everything.
    if (!newToken) {
        ClearGCalCache();
    }
    CurrentToken = newToken;
}
// We need to keep track of ShoreTel and UCB status also.
var ShoreTelLoggedIn = false;
var ShoreTelUCBGood = false;
if (stComm)
    stComm.onready = function (loggedIn, connected, isUCBEnabled) {
        DEBUG && LOG('GCAL received onready() from core, loggedIn = ' + loggedIn + ', connected = ' + connected + ', isUCBEnabled = ' + isUCBEnabled);
        // UCB status changed?
        if (isUCBEnabled != ShoreTelUCBGood) {
            // Status has changed, save in global flag.
            ShoreTelUCBGood = isUCBEnabled;
            if (ShoreTelUCBGood) {
                // UCB wasn't good but now it is, schedule our GCAL process soon.
                ScheduleGCalProcess(GCAL_SHORT_REFRESH_TIME);
            }
        }
        // ShoreTel logged in state changed?
        if (loggedIn != ShoreTelLoggedIn) {
            // Status has changed, save in global flag.
            ShoreTelLoggedIn = loggedIn;
            if (ShoreTelLoggedIn) {
                // Wasn't logged in, but is now...make sure free/busy list is processed next time.
                FBNeedUpdate = true;
            }
        }
    };
// Clear the cache.
function ClearGCalCache() {
    DEBUG && LOG('ClearGCalCache(), CLEARING GCAL CACHE!');
    GCalSyncToken = null;
    GCalEvents.clear();
}
// Helps us to schedule one future run of GCalProcess.
function ScheduleGCalProcess(FutureMS) {
    DEBUG && LOG('ScheduleGCalProcess(), Setting to run in ' + FutureMS + 'ms');
    // Clear current scheduled time.
    if (GCalTimeoutID > 0) {
        clearTimeout(GCalTimeoutID);
    }
    // Schedule to run as indicated.
    GCalTimeoutID = setTimeout(GCalProcess, FutureMS);
}
// This starts off the cache update.
function GCalProcess() {
    DEBUG && LOG('GCalProcess(), CurrentToken = ' + CurrentToken + ', ShoreTelUCBGood = ' + ShoreTelUCBGood);
    if (CurrentToken && ShoreTelUCBGood) {
        // Execute calendar request.
        GCalExecuteRequest(CreateGCalRequestParams());
    }
}
// Globals used in creation of GCAL request.
var GCalSyncToken = null;
var GCalTimeToken = null;
// Forms the GCAL events request.
function CreateGCalRequestParams(pageToken) {
    // Always put in maxResults.
    var qString = '?maxResults=' + GCAL_EVENTS_MAXRESULTS.toString();
    qString += '&showDeleted=true';
    // If sync token is set, use it to retrieve changes since last request.
    // If no valid sync token, then we're doing a full refresh. Use current time as "floor".
    // In either case above, we could be asking for subsequent pages, if Google paginated the response.
    if (GCalSyncToken) {
        qString += '&syncToken=' + encodeURIComponent(GCalSyncToken);
    }
    else {
        // If sync token and page token both null, set the timeMin "floor" to now minus some days.
        // Otherwise, if there is a page token, use as saved in the original first page request.
        if (!pageToken) {
            GCalTimeToken = new Date(Date.now() - GCAL_EVENTS_SINCE_MS_AGO);
        }
        qString += '&timeMin=' + encodeURIComponent(GCalTimeToken.toISOString());
    }
    // We'll need to loop, page by page, if so indicated.
    if (pageToken)
        qString += '&pageToken=' + encodeURIComponent(pageToken);
    DEBUG && LOG('CreateGCalRequestParams(), Params = ' + qString);
    return (qString);
}
// Execute the GCAL request.
function GCalExecuteRequest(qString) {
    if (CurrentToken) {
        var req = GCAL_EVENTS_REQUEST + qString;
        DEBUG && LOG('GCalExecuteRequest(), Executing request = ' + req);
        $.ajax(req, { headers: { "Authorization": 'Bearer ' + CurrentToken } })
            .done(ProcessGCalPage)
            .fail(ProcessGCalFailureResponse);
    }
    else {
        DEBUG && LOG('GCalExecuteRequest(), ERROR, CurrentToken not valid');
    }
}
// Successful response from GCAL request.
function ProcessGCalPage(response) {
    // Success, the Google has spoken...
    var gcalEventsResp = response;
    // Process items received.
    if (gcalEventsResp) {
        var nrItems = 0;
        if (gcalEventsResp.items)
            nrItems = gcalEventsResp.items.length;
        DEBUG && LOG('ProcessGCalPage(), Calendar Title: ' + gcalEventsResp.summary + ', Nr Items = ' + nrItems);
        // Process every calendar item.
        for (var i = 0; i < nrItems; i++) {
            var gcalItem = gcalEventsResp.items[i];
            ProcessGCALEvent(gcalItem);
        }
        // If anything has changed, trigger a free/busy update (next time the updater awakens).
        if (nrItems > 0)
            FBNeedUpdate = true;
        // If a page token was returned, we need to request and process next page.
        // Otherwise, a sync token should be present...save it and schedule next checkup.
        if (gcalEventsResp.nextPageToken) {
            // New request for next page.
            GCalExecuteRequest(CreateGCalRequestParams(gcalEventsResp.nextPageToken));
        }
        else if (gcalEventsResp.nextSyncToken) {
            // Save sync token and schedule next process.
            GCalSyncToken = gcalEventsResp.nextSyncToken;
            ScheduleGCalProcess(GetNormalRefreshTime());
        }
        else {
            // Should not happen.
            DEBUG && LOG('ProcessGCalPage(), Error, Neither SyncToken nor PageToken were present');
            ClearGCalCache();
            ScheduleGCalProcess(GCAL_ERROR_REFRESH_TIME);
        }
    }
    else {
        // Google says nothing.  Should not happen.
        DEBUG && LOG("ProcessGCalPage(), ERROR:  Calendar request returned null");
        ClearGCalCache();
        ScheduleGCalProcess(GetNormalRefreshTime());
    }
}
// Unsuccessful response from GCAL.
function ProcessGCalFailureResponse(jqXHR, textStatus, error) {
    // What we have here is a failure to communicate...
    var statusCode = 0;
    if (jqXHR && jqXHR.status) {
        statusCode = jqXHR.status;
    }
    DEBUG && LOG('ChromePhoneCalendar::ProcessGCalFailureResponse(), Failure, status = ' + statusCode);
    // No matter the error, we'll clear our GCal data completely.
    ClearGCalCache();
    if (statusCode == 410) {
        // Google says incremental update not possible, we need full refresh now...No need to wait.
        GCalProcess();
    }
    else if (statusCode == 403) {
        // Google says "forbidden". Try later.
        ScheduleGCalProcess(GCAL_ERROR_REFRESH_TIME);
    }
    else {
        // Unknown error. Wait a bit and do the full refresh.
        ScheduleGCalProcess(GCAL_ERROR_REFRESH_TIME);
    }
}
// Google says this event is new, has changed, etc.
function ProcessGCALEvent(e) {
    DEBUG && LOG('ProcessGCALEvent(), GCAL Event, id = ' + e.id + ', Raw Event = ' + JSON.stringify(e) + '\n');
    // Keep our cache up to date.
    if (GCalEvents.has(e.id)) {
        // Our cache has this item. Must be an update or delete.
        if (e.status == 'cancelled') {
            // Delete
            DEBUG && LOG('ProcessGCALEvent(), DELETING GCAL Event from cache, id = ' + e.id);
            GCalEvents.delete(e.id);
        }
        else {
            // Update
            DEBUG && LOG('ProcessGCALEvent(), UPDATING GCAL Event in cache, id = ' + e.id);
            GCalEvents.set(e.id, e);
        }
    }
    else {
        // Not in our cache. Must be a new item.
        if (e.status != 'cancelled') {
            GCalEvents.set(e.id, e);
            DEBUG && LOG('ProcessGCALEvent(), ADDING GCAL Event to cache, id = ' + e.id);
        }
    }
    // Now process GCAL events with regard to updating associated UCB events.
    // We only process GCAL events we own and ones that definitely have UCB information in their description.
    if (e.organizer && e.organizer.self) {
        // My GCAL event.  See if description holds UCB information. We only process ones that do.
        var pCode = ParticipantCodeFromDescription(e);
        if (pCode) {
            // Has UCB information in the description field. Further processing.
            ProcessGCALForUCB(e, pCode);
        }
        else {
            // But if there is no UCB information in the description, we need to be sure there is no UCB information in private data.
            // If there is, delete it and delete UCB meeting if exists.
            var ucbCodes = UCBCodesFromPrivateData(e);
            if (ucbCodes.mtgId) {
                // Delete private data.
                delete e.extendedProperties.shared['ShoreTelUCBId'];
                delete e.extendedProperties.shared['ShoreTelUCBPCode'];
                GCalExecuteUpdate(e);
                // Delete UCB meeting, if exists.
                if (ShoreTelHasUCB(ucbCodes.mtgId)) {
                    stComm.conf_deleteMeeting(ucbCodes.mtgId, function (resp) {
                        var respStr = JSON.stringify(resp);
                        DEBUG && LOG('ProcessGCALForUCB(), conf_deleteMeeting() ASYNC, Success, resp = ' + respStr);
                    }, function (resp) {
                        var respStr = JSON.stringify(resp);
                        DEBUG && LOG('ProcessGCALForUCB(), conf_deleteMeeting() ASYNC, Failure, resp = ' + respStr);
                    });
                }
            }
        }
    }
}
var GCAL_STCREATED_LS = 'STCreatedBridge:';
// Process owned GCAL event which has been determined to have an associated UCB event in description.
function ProcessGCALForUCB(e, pCode) {
    DEBUG && LOG('ProcessGCALForUCB(), GCAL event found containing UCB Description, PCode = ' + pCode);
    // Three cases:
    //
    // 1. GCAL event deleted:  Find UCB meeting ID from GCAL private data, delete UCB conference bridge.
    //
    // 2. GCAL event updated:  GCAL event with UCB in private data has changed. Send update to UCB conference
    //                         bridge to update. We do this pretty blindly, regardless of what has changed.
    //
    // 3. GCAL event new:      GCAL event newly created. This means GCAL private data has not been set yet.
    //                         Only a placeholder UCB event has been created. Information should be in local storage.
    //                         Need to update UCB and update GCAL to set private data.
    // See if this GCAL event has UCB meeting ID in private data.
    // If so, continue to test for Case 1 or 2.
    var ucbCodes = UCBCodesFromPrivateData(e);
    // If there was a UCB meeting ID in the private data AND stComm says this meeting ID really exists,
    // then handle case 1 or 2.
    if (ucbCodes.mtgId && (ucbCodes.pCode == pCode)) {
        if (ShoreTelHasUCB(ucbCodes.mtgId)) {
            // Must be case 1 or 2 above because we found the private data.
            if (e.status == 'cancelled') {
                // Case 1, deleted GCAL event. Delete UCB meeting.
                DEBUG && LOG('ProcessGCALForUCB(), ASYNC, Found cancelled meeting (Case 1) = ' + ucbCodes.mtgId + ', for GCAL id = ' + e.id);
                stComm.conf_deleteMeeting(ucbCodes.mtgId, function (resp) {
                    var respStr = JSON.stringify(resp);
                    DEBUG && LOG('ProcessGCALForUCB(), conf_deleteMeeting() ASYNC, Success, resp = ' + respStr);
                }, function (resp) {
                    var respStr = JSON.stringify(resp);
                    DEBUG && LOG('ProcessGCALForUCB(), conf_deleteMeeting() ASYNC, Failure, resp = ' + respStr);
                });
            }
            else {
                // Case 2, changed GCAL event
                DEBUG && LOG('ProcessGCALForUCB(), ASYNC, Found updated meeting (Case 2) = ' + ucbCodes.mtgId + ', for GCAL id = ' + e.id);
                UpdateUCB(e, ucbCodes.mtgId, pCode);
            }
        }
        else {
            DEBUG && LOG('ProcessGCALForUCB(), ASYNC, Meeting ID in GCAL private data, not in ShoreTel list, skip, Meeting ID = ' + ucbCodes.mtgId + ', GCAL meeting status = ' + e.status);
        }
    }
    else {
        // There was no meeting ID in the GCAL private data, or the meeting ID in the private data does NOT match that in the description.
        if (ucbCodes.pCode != pCode) {
            // This could be case where user deleted a UCB from a meeting then added another one shortly afterward.
            DEBUG && LOG('ProcessGCALForUCB(), Special case (possible case 3), Meeting ID = ' + ucbCodes.mtgId + ', pCode in private data = ' + ucbCodes.pCode + ' NO MATCH for pCode in Description = ' + pCode);
            // Since meeting in private data doesn't match, if it really exists, then delete it from ShoreTel side.
            if (ShoreTelHasUCB(ucbCodes.mtgId)) {
                DEBUG && LOG('ProcessGCALForUCB(), Special case (possible case 3), DELETING Meeting ID = ' + ucbCodes.mtgId);
                stComm.conf_deleteMeeting(ucbCodes.mtgId, function (resp) {
                    var respStr = JSON.stringify(resp);
                    DEBUG && LOG('ProcessGCALForUCB(), conf_deleteMeeting() ASYNC, Success, resp = ' + respStr);
                }, function (resp) {
                    var respStr = JSON.stringify(resp);
                    DEBUG && LOG('ProcessGCALForUCB(), conf_deleteMeeting() ASYNC, Failure, resp = ' + respStr);
                });
            }
        }
        // If it (meeting in description) is a brand new GCAL event, there will be an associated entry in local storage (set by the content page).
        // So, lets test Case 3 now.
        var lsKey = GCAL_STCREATED_LS + pCode; // Key is CONSTANT:<participant code>
        // Look for local storage entry.  All the rest is handled Async.
        chrome.storage.local.get(lsKey, function (lsObj) {
            // Is there a local storage entry for this UCB meeting?
            if (lsObj && lsObj[lsKey]) {
                // Valid, this is Case 3, above. Get UCB meeting ID which is the value (given the key, lsKey);
                var mtgID = lsObj[lsKey];
                if (ShoreTelHasUCB(mtgID)) {
                    DEBUG && LOG('ProcessGCALForUCB(), chrome.storage.local.get() ASYNC, Found new ST Meeting ID (Case 3) = ' + mtgID + ', for GCAL id = ' + e.id + ', GCAL status = ' + e.status);
                    // We've got the meeting ID we need.  We're only going to try the update once. Remove the chrome storage key
                    // that triggered us so we don't do this again.
                    chrome.storage.local.remove(lsKey);
                    // e is GCAL event
                    if (e.status == 'cancelled') {
                        // Must've been quickly deleted after newly created. Delete from UCB.
                        stComm.conf_deleteMeeting(mtgID, function (resp) {
                            var respStr = JSON.stringify(resp);
                            DEBUG && LOG('ProcessGCALForUCB(), conf_deleteMeeting() ASYNC, Success, resp = ' + respStr);
                        }, function (resp) {
                            var respStr = JSON.stringify(resp);
                            DEBUG && LOG('ProcessGCALForUCB(), conf_deleteMeeting() ASYNC, Failure, resp = ' + respStr);
                        });
                    }
                    else {
                        // Normal case, update UCB with all details.
                        UpdateUCB(e, mtgID, pCode);
                    }
                }
                else {
                    DEBUG && LOG('ProcessGCALForUCB(), ASYNC, Meeting ID in local storage, not in ShoreTel list, skip, Meeting ID = ' + mtgID);
                }
            }
            else {
                DEBUG && LOG('ProcessGCALForUCB(), ASYNC, PCode in description, not in GCAL private data and no local storage, strange, meeting ID = ' + pCode);
            }
        });
    }
}
// Search ShoreTel conference list by meeting ID.
function ShoreTelHasUCB(mtgID) {
    var found = false;
    found = mtgID && stComm && stComm.conferences && stComm.conferences.has(mtgID);
    return (found);
}
// Creates IConference object, fills it with data from GCAL event and
// sends to UCB as an update. Assumption is UCB event already created.
// Also checks/validates the UCB information in GCAL event and updates
// GCAL event if necessary.
function UpdateUCB(gcalEvent, ucbMtgID, pCode) {
    var ucbConf = {};
    // Copy what we can from GCAL to ShoreTel.
    ucbConf.id = ucbMtgID;
    ucbConf.title = gcalEvent.summary;
    ucbConf.meetingLocation = gcalEvent.location;
    ucbConf.isScheduled = true;
    // ShoreTel wants date/times in Unix form.
    // NOTES to future self and other programmers:
    // GCAL start/end contains either date (for all day events) or dateTime (normal events).
    // dateTime assumed to always include time zone offset and can be parsed as is.
    // date has only date so time must be force set to local time values.
    // Start of meeting.
    var startUnix = 0;
    if (gcalEvent.start.dateTime) {
        // Normal meeting.
        startUnix = Date.parse(gcalEvent.start.dateTime);
    }
    else {
        // All day meeting.
        startUnix = GetDateMidnight(gcalEvent.start.date).getTime();
    }
    ucbConf.start = startUnix;
    // End of meeting.
    var endUnix = 0;
    if (gcalEvent.end.dateTime) {
        // Normal meeting.
        endUnix = Date.parse(gcalEvent.end.dateTime);
    }
    else {
        // All day meeting.
        endUnix = GetDateMidnight(gcalEvent.end.date).getTime();
    }
    // ShoreTel wants duration, in minutes.
    ucbConf.duration = (endUnix - startUnix) / 1000 / 60; // To minutes.
    // ShoreTel end time is end of the meeting (or end of last meeting for recurring...adjusted by ProcessGCALRecurrence(), if so).
    ucbConf.end = endUnix;
    // RECURRENCE
    // Make sure start, end and duration are set above, before recurrence processing.
    var recurValid = true; // Recur either absent or valid.
    if (gcalEvent.recurrence && gcalEvent.recurrence.length > 0) {
        // This is a recurring meeting. UCB can't handle all types. Process/Validate.
        DEBUG && LOG('UpdateUCB(), Recurring meeting = ' + JSON.stringify(gcalEvent.recurrence));
        // If this returns a UCB valid recurrence, ucbConf has been set with recurringType and end values.
        if (ProcessGCALRecurrence(gcalEvent.recurrence, ucbConf) == UCBRecurrenceType.Invalid) {
            recurValid = false; // Process found invalid (for UCB ) recurrence.
        }
    }
    // Don't continue if invalid recurrence.
    if (recurValid) {
        // ShoreTel needs organizer as an organizer attendee.
        ucbConf.attendees = [];
        ucbConf.attendees[0] = {};
        ucbConf.attendees[0].id = gcalEvent.organizer.email;
        // For organizer name, use ShoreTel value.
        // If null, use GCAL display name, if null, use "unknown".
        var myName = stComm.name;
        if (!myName)
            myName = gcalEvent.organizer.displayName;
        if (!myName)
            myName = gcalEvent.organizer.email; // Connect client doesn't like null names.
        myName = myName + ',' + gcalEvent.organizer.email; // Connect wants name to be name,email.
        ucbConf.attendees[0].name = myName;
        ucbConf.attendees[0].type = 0; //ConferenceEnums.AttendeeType.Organizer;
        // Now the "real" attendees, if any in GCAL.
        // Note the GCAL organizer also appears in attendee list if there are other attendees
        // otherwise, only appears in organizer section.  In any case, don't duplicate him/her in ShoreTel
        // attendee list.  Note since I added one in ucbConf above, j = i + 1.
        if (gcalEvent.attendees) {
            for (var i = 0; i < gcalEvent.attendees.length; i++) {
                if (!gcalEvent.attendees[i].organizer) {
                    var j = i + 1;
                    // Copy each GCAL attendee, a, to UCB meeting.
                    ucbConf.attendees[j] = {};
                    ucbConf.attendees[j].id = gcalEvent.attendees[i].email;
                    var displayName = gcalEvent.attendees[i].displayName;
                    if (!displayName)
                        displayName = gcalEvent.attendees[i].email; // Connect client doesn't like null names.
                    displayName = displayName + ',' + gcalEvent.attendees[i].email; // Connect wants name to be name,email.
                    ucbConf.attendees[j].name = displayName;
                    ucbConf.attendees[j].type = 1; //ConferenceEnums.AttendeeType.Presenter;
                }
            }
        }
        DEBUG && LOG('UpdateUCB(), About to update UCB');
        stComm.conf_updateMeeting(ucbConf, function (resp) {
            DEBUG && LOG('UpdateUCB(), conf_updateMeeting() ASYNC, Success, resp = ' + JSON.stringify(resp));
            // If GCAL does not already have meeting ID and PCode in private data, update it.
            TestUpdateGCALPrivateData(gcalEvent, ucbMtgID, pCode);
        }, function (resp) {
            var respStr = JSON.stringify(resp);
            DEBUG && LOG('UpdateUCB(), conf_updateMeeting() ASYNC, Failure, resp = ' + respStr);
            // UCB doesn't like us changing past meetings.  Do it anyway and just ignore the errors.
            if (resp.statusKey && (resp.statusKey == 'E_SCHEDULED_MEETING_IN_PAST')) {
                DEBUG && LOG('UpdateUCB(), conf_updateMeeting() ASYNC, Failure, Ignoring error');
            }
            else {
                ChromeNotify('GCALErrorUpdatingBridge', true, respStr);
            }
        });
    }
    else {
        ChromeNotify('GCALErrorBridgeRecurrence', true);
    }
}
// Create a date/time object for Midnight local time given date string yyyy-mm-dd.
function GetDateMidnight(dateStr) {
    var d = new Date();
    try {
        if (dateStr) {
            var dSplit = dateStr.split('-');
            if (dSplit && (dSplit.length == 3)) {
                d = new Date(parseInt(dSplit[0]), parseInt(dSplit[1]) - 1, parseInt(dSplit[2]), 0, 0, 0);
            }
        }
    }
    catch (ex) {
        DEBUG && LOG('GetDateMidnight(), Exception = ' + ex);
    }
    return (d);
}
function TestUpdateGCALPrivateData(gcalEvent, ucbMtgID, pCode) {
    // See if values already exist in gcalEvent.
    var gcalExistingUCBId = null;
    var gcalExistingUCBPCode = null;
    if (gcalEvent && gcalEvent.extendedProperties && gcalEvent.extendedProperties.shared) {
        if (gcalEvent.extendedProperties.shared['ShoreTelUCBId']) {
            gcalExistingUCBId = gcalEvent.extendedProperties.shared['ShoreTelUCBId'];
        }
        if (gcalEvent.extendedProperties.shared['ShoreTelUCBPCode']) {
            gcalExistingUCBPCode = gcalEvent.extendedProperties.shared['ShoreTelUCBPCode'];
        }
    }
    // If there are values and they don't match existing, update them in GCAL object.
    if (ucbMtgID && pCode) {
        if (!gcalExistingUCBId || (ucbMtgID != gcalExistingUCBId) || !gcalExistingUCBPCode || (pCode != gcalExistingUCBPCode)) {
            // Update values.
            if (!gcalEvent.extendedProperties)
                gcalEvent.extendedProperties = { private: {}, shared: {} };
            else if (!gcalEvent.extendedProperties.shared)
                gcalEvent.extendedProperties.shared = {};
            gcalEvent.extendedProperties.shared['ShoreTelUCBId'] = ucbMtgID;
            gcalEvent.extendedProperties.shared['ShoreTelUCBPCode'] = pCode;
            // Send to Google.
            GCalExecuteUpdate(gcalEvent);
        }
    }
}
// Execute a GCAL update.
function GCalExecuteUpdate(e) {
    if (CurrentToken) {
        var req = GCAL_EVENTS_REQUEST + '/' + e.id;
        DEBUG && LOG('GCalExecuteUpdate(), GCAL Event Obj = ' + JSON.stringify(e));
        var ajaxSettings = {};
        ajaxSettings.url = req;
        ajaxSettings.headers = { "Authorization": 'Bearer ' + CurrentToken };
        ajaxSettings.type = 'PUT';
        ajaxSettings.contentType = 'application/json';
        ajaxSettings.data = JSON.stringify(e);
        ajaxSettings.success = UpdateItemSuccess;
        ajaxSettings.error = UpdateItemFailure;
        var xhr = $.ajax(ajaxSettings);
        DEBUG && LOG('GCalExecuteUpdate(), Ajax sync resp = ' + JSON.stringify(xhr));
    }
    else {
        DEBUG && LOG('GCalExecuteUpdate(), ERROR, CurrentToken not valid');
    }
}
function UpdateItemSuccess(resp) {
    DEBUG && LOG('UpdateItemSuccess(), resp = ' + JSON.stringify(resp));
    TestSendTabMessages();
}
function UpdateItemFailure(jqXHR, textStatus, error) {
    var statusCode = 0;
    if (jqXHR && jqXHR.status) {
        statusCode = jqXHR.status;
    }
    DEBUG && LOG('UpdateItemFailure(), status = ' + statusCode);
}
// Ask Google for the free/busy list and update ShoreTel using CAS CHM Scheduling API.
// Used in query and in success.
var FreeBusyBegin;
var FreeBusyEnd;
function GCalQueryFreeBusy() {
    // We only do this if both Google and ShoreTel are connected and logged in.
    if (CurrentToken && ShoreTelLoggedIn) {
        // Time to Google free/busy list.
        var req = GCAL_FREEBUSY_REQUEST;
        // For this time period.
        FreeBusyBegin = new Date(Date.now() - GCAL_FREEBUSY_SINCE_MS_AGO);
        FreeBusyEnd = new Date(Date.now() + GCAL_FREEBUSY_MS_FROM_NOW);
        var body = {
            "timeMin": FreeBusyBegin.toISOString(),
            "timeMax": FreeBusyEnd.toISOString(),
            "items": [{ "id": "primary" }]
        };
        var ajaxSettings = {};
        ajaxSettings.url = req;
        ajaxSettings.headers = { "Authorization": 'Bearer ' + CurrentToken };
        ajaxSettings.type = 'POST';
        ajaxSettings.contentType = 'application/json';
        ajaxSettings.data = JSON.stringify(body);
        ajaxSettings.success = FreeBusySuccess;
        ajaxSettings.error = FreeBusyFailure;
        var xhr = $.ajax(ajaxSettings);
        DEBUG && LOG('GCalQueryFreeBusy(), Ajax sync resp = ' + JSON.stringify(xhr));
    }
    else {
        DEBUG && LOG('GCalQueryFreeBusy(), ERROR, CurrentToken not valid or ShoreTel user not logged in');
    }
}
// See CAS specification, Chapter 20, CHM Scheduling API for details, if you dare.
var CALENDAR_SOURCE = "Outlook";
var TIMEZONE_STRING = "Bias=0,DaylightBias=0,DaylightName=UTC,DaylightRule=00-00-00-00-00-00,StandardBias=0,StandardName=Greenwich Standard Time,StandardRule=00-00-00-00-00-00";
// We only use "background free/standard" and "in a meeting" types.  Hard code per CAS spec.
var CHM_BACKGROUND_STD = -1;
var CHM_IN_MEETING = 2;
function FreeBusySuccess(resp) {
    DEBUG && LOG('FreeBusySuccess(), resp = ' + JSON.stringify(resp));
    // Now reset the date/time of last update.
    FBLastUpdate = new Date(Date.now());
    // Process the busy list received into array of items for ShoreTel.
    // Must see CAS specification to make sense of this.
    var stItems = []; // Array to hold items (each item also an array).
    // First item is the "background free" which covers entire duration we requested above.
    // We "lay down" all the time as "free/standard".
    stItems.push(["", -1, STDTString(FreeBusyBegin.toISOString()), STDTString(FreeBusyEnd.toISOString()), CHM_BACKGROUND_STD, "", "", ""]);
    var i = 1; // Count them and use as native ID.
    // Now go through Google response, adding "busy/in meeting" times.
    if (resp && resp.calendars && resp.calendars.primary) {
        if (resp.calendars.primary.busy) {
            var calendarBusyItemsList = resp.calendars.primary.busy;
            for (var _i = 0, calendarBusyItemsList_1 = calendarBusyItemsList; _i < calendarBusyItemsList_1.length; _i++) {
                var busyItem = calendarBusyItemsList_1[_i];
                DEBUG && LOG('FreeBusySuccess(), BusyItem:  Start = ' + busyItem.start + ', End = ' + busyItem.end);
                stItems.push([i.toString(), -1, STDTString(busyItem.start), STDTString(busyItem.end), CHM_IN_MEETING, "", "", ""]);
                i++;
            }
        }
    }
    DEBUG && LOG('FreeBusySuccess(), stItems = ' + JSON.stringify(stItems));
    stComm.chm_upload(CALENDAR_SOURCE, TIMEZONE_STRING, stItems, function (result) {
        DEBUG && LOG('FreeBusySuccess(), chm_upload Success = ' + JSON.stringify(result));
    }, function (error) {
        DEBUG && LOG('FreeBusySuccess(), chm_upload did not succeed = ' + JSON.stringify(error));
    });
}
// Date/Time strings in ShoreTel object need specific format.
// Assumes javascript "ISOString" input.
function STDTString(isoStr) {
    var s = null;
    if (isoStr) {
        s = isoStr.replace(/[-:Z]/g, '').split('.')[0];
    }
    return (s);
}
function FreeBusyFailure(jqXHR, textStatus, error) {
    var statusCode = 0;
    if (jqXHR && jqXHR.status) {
        statusCode = jqXHR.status;
    }
    DEBUG && LOG('FreeBusyFailure(), status = ' + statusCode);
    // Reset flag so we try again the very next time.
    FBNeedUpdate = true;
}
// See if any tabs waiting for GCAL discovery.
function TestSendTabMessages() {
    if (TabMessages.size > 0) {
        var delIdArray = [];
        for (var _i = 0, _a = Array.from(TabMessages); _i < _a.length; _i++) {
            var _b = _a[_i], id = _b[0], tm = _b[1];
            try {
                var e = GCALSearchPCode(tm.pCode);
                if (e) {
                    delIdArray.push(id);
                    var resp = {};
                    resp['Target'] = 'GCAL';
                    resp['Result'] = 'Found';
                    resp['PCode'] = tm.pCode;
                    resp['GCALEvent'] = e;
                    chrome.tabs.sendMessage(id, resp);
                }
            }
            catch (ex) {
                DEBUG && LOG('TestSendTabMessages(), Exception = ' + ex.message);
            }
        }
        for (var _c = 0, delIdArray_1 = delIdArray; _c < delIdArray_1.length; _c++) {
            var id = delIdArray_1[_c];
            if (TabMessages.has(id))
                TabMessages.delete(id);
        }
    }
}
var rxRRULE = new RegExp('(RRULE:)(.*?)("|$)');
// Example:  RRULE:FREQ=WEEKLY;UNTIL=20161202T190000Z;BYDAY=FR
// UCB only supports daily, weekly, biweekly, or monthly.
var UCBRecurrenceType;
(function (UCBRecurrenceType) {
    UCBRecurrenceType[UCBRecurrenceType["Invalid"] = -1] = "Invalid";
    UCBRecurrenceType[UCBRecurrenceType["Daily"] = 0] = "Daily";
    UCBRecurrenceType[UCBRecurrenceType["Weekly"] = 1] = "Weekly";
    UCBRecurrenceType[UCBRecurrenceType["Biweekly"] = 2] = "Biweekly";
    UCBRecurrenceType[UCBRecurrenceType["Monthly"] = 3] = "Monthly";
})(UCBRecurrenceType || (UCBRecurrenceType = {}));
// Get RRULE, parse it, then validate that we can support.
function ProcessGCALRecurrence(rules, ucbConf) {
    var rtn = UCBRecurrenceType.Invalid;
    try {
        if (rules && (rules.length > 0)) {
            for (var i = 0; i < rules.length; i++) {
                var rxa = rxRRULE.exec(rules[i]);
                if (rxa && rxa.length > 1) {
                    var rrule = rxa[2];
                    DEBUG && LOG('ParseGCALRecurrence(), rrule = ' + rrule);
                    rtn = ValidateRuleObj(ParseNV(rrule), ucbConf);
                    break;
                }
            }
        }
    }
    catch (ex) {
        DEBUG && LOG('ParseGCALRecurrence(), Exception = ' + ex);
    }
    return (rtn);
}
// Create object out of NV pairs.
// From example above:
// {FREQ: WEEKLY
//  UNTIL: 20161202T190000Z
//  BYDAY: FR}
function ParseNV(nvs) {
    var rtnObj = {};
    if (nvs) {
        // Split at semicolon giving us NV pairs.
        var nvsa = nvs.split(';');
        if (nvsa && (nvsa.length > 0)) {
            // For each NV pair,
            for (var i = 0; i < nvsa.length; i++) {
                if (nvsa[i]) {
                    // Split at = to get name and value separately
                    var nva = nvsa[i].split('=');
                    if (nva && nva.length == 2) {
                        // Put in object.
                        rtnObj[nva[0]] = nva[1];
                    }
                }
            }
        }
    }
    return (rtnObj);
}
var MILLISECONDS_PER_DAY = 86400000;
var MILLISECONDS_PER_MINUTE = 60000;
function ValidateRuleObj(ruleObj, ucbConf) {
    var rType = UCBRecurrenceType.Invalid;
    if (ruleObj && ruleObj['FREQ']) {
        var freq = ruleObj['FREQ'];
        // No support for multiple days.
        if (!ruleObj['BYDAY'] || !ruleObj['BYDAY'].includes(',')) {
            // Break out by supported frequency.
            // CountDays may be used to calculate end time further down.
            var countDays = 0;
            switch (freq) {
                case 'DAILY':
                    rType = UCBRecurrenceType.Daily;
                    countDays = 1;
                    break;
                case 'WEEKLY':
                    rType = UCBRecurrenceType.Weekly;
                    countDays = 7;
                    if (ruleObj['INTERVAL'] && (ruleObj['INTERVAL'] == '2')) {
                        rType = UCBRecurrenceType.Biweekly;
                        countDays = 14;
                    }
                    break;
                case 'MONTHLY':
                    rType = UCBRecurrenceType.Monthly;
                    countDays = 31; // This will give us an approximation only (but = or greater than actual)...difficult to do exactly.
                    break;
            }
            // No intervals except biweekly (handled above).
            if (rType != UCBRecurrenceType.Biweekly && ruleObj['INTERVAL'] && (ruleObj['INTERVAL'] != '1')) {
                rType = UCBRecurrenceType.Invalid;
            }
            // Rest of tests unnecessary if not valid.
            if (rType != UCBRecurrenceType.Invalid) {
                // Now figure out when this recurrence period ends.
                // Example iso8601 compact is assumed:  20170113T203000Z
                var endRecurUnix = 0; // Never ends.  Assume, then correct below.
                if (ruleObj['UNTIL']) {
                    var iso8601dt = ruleObj['UNTIL'];
                    // Parse doesn't like compact.  Change decorated iso8601.
                    // Note this will break if Google changes format.
                    iso8601dt =
                        iso8601dt.substr(0, 4) + '-' +
                            iso8601dt.substr(4, 2) + '-' +
                            iso8601dt.substr(6, 3) +
                            iso8601dt.substr(9, 2) + ':' +
                            iso8601dt.substr(11, 2) + ':' +
                            iso8601dt.substr(13);
                    // GCAL uses START of last meeting as end.  UCB wants end of last meeting.  Add duration seconds.
                    endRecurUnix = Date.parse(iso8601dt) + (ucbConf.duration * MILLISECONDS_PER_MINUTE);
                }
                if (ruleObj['COUNT']) {
                    var count = parseInt(ruleObj['COUNT']);
                    // GCAL uses START of last meeting as end.  UCB wants end of last meeting.  Add duration seconds.
                    endRecurUnix = ucbConf.start + ((count - 1) * countDays * MILLISECONDS_PER_DAY) + (ucbConf.duration * MILLISECONDS_PER_MINUTE);
                }
            }
        }
    }
    if (rType != UCBRecurrenceType.Invalid) {
        ucbConf.recurringType = rType;
        ucbConf.end = endRecurUnix;
    }
    return (rType);
}
function UCBCodesFromPrivateData(e) {
    var c = {};
    if (e.extendedProperties && e.extendedProperties.shared) {
        if (e.extendedProperties.shared['ShoreTelUCBId']) {
            c.mtgId = e.extendedProperties.shared['ShoreTelUCBId'];
        }
        if (e.extendedProperties.shared['ShoreTelUCBPCode']) {
            c.pCode = e.extendedProperties.shared['ShoreTelUCBPCode'];
        }
    }
    return (c);
}
// Get UCB participant code from description of GCAL event.
function ParticipantCodeFromDescription(e) {
    var pCode = null;
    if (e && e.description) {
        var desc = e.description;
        // Find bracket.  Test for "Mitel" and "ShoreTel"
        var stIndex = desc.indexOf(chrome.i18n.getMessage('GCALBridgeBracket'));
        if (stIndex == -1)
            stIndex = desc.indexOf(chrome.i18n.getMessage('OLDGCALBridgeBracket'));
        if (stIndex > -1) {
            // Find participant code after bracket.
            var pCodeStr = chrome.i18n.getMessage('GCALParticipantCode');
            // Pull out just the code that follows localized heading.
            var pcIndex = desc.indexOf(pCodeStr, stIndex) + pCodeStr.length;
            // Get digits until not a digit.
            var done = false;
            while (!done && (pcIndex < desc.length)) {
                if (IsDigit(desc[pcIndex])) {
                    pCode = (pCode == null) ? desc[pcIndex] : pCode + desc[pcIndex];
                }
                else {
                    done = true;
                }
                pcIndex++;
            }
        }
    }
    return (pCode);
}
function IsDigit(c) {
    if ((c < '0') || (c > '9'))
        return false;
    else
        return true;
}
// Generate a Chrome notification.  We will always use the i18n string as the notification ID.
function ChromeNotify(notificationID, requireUserInteraction, optionalSubMessage) {
    var notificationOptions = {
        'type': 'basic',
        'title': chrome.i18n.getMessage('ExtensionName'),
        'iconUrl': chrome.extension.getURL('images/icons/shoretel-logo-inverted.png'),
        'priority': 2,
        'message': chrome.i18n.getMessage(notificationID) + (optionalSubMessage ? '\n\n' + optionalSubMessage : '')
    };
    if (requireUserInteraction)
        notificationOptions['requireInteraction'] = true;
    chrome.notifications.create(notificationID, notificationOptions, requireUserInteraction ? ChromeNotifyCB : ChromeNotifyClear);
}
function ChromeNotifyClear(notificationID) {
    setTimeout(function () {
        chrome.notifications.clear(notificationID);
    }, NOTIFICATION_DURATION_MS);
}
function ChromeNotifyCB(notificationID) {
}
// function showObject(o: Object) {
//     for (var id in o) {
//         try {
//             if (typeof (o[id]) == "object") {
//                 DEBUG && LOG('Object: ' + id);
//                 showObject(o[id]);
//             }
//             if (typeof (o[id]) == "function") {
//                 DEBUG && LOG('Function: ' + id + ', ' + o[id].toString());
//             }
//         }
//         catch (err) {
//             DEBUG && LOG('Function: ' + id + ', Inaccessible');
//         }
//     }
// }
//# sourceMappingURL=stGCALBackground.js.map