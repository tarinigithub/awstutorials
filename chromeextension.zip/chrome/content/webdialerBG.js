
var menus = null;
var menuIds = null;
var windowID = -1;
var tabId = -1;
var webDialerLoggedIn = false;
var webDialerConnected = false;
var contextMenu = undefined;
var callLabel = chrome.i18n.getMessage('webdialerCall');
var shoretel = new ShoreTel('webdialerBG');

if ((callLabel == null) || (callLabel.length == 0)) {
    callLabel = 'Call ';
}

shoretel.onready = function (loggedIn, connected) {
    webDialerLoggedIn = loggedIn;
    webDialerConnected = connected;
}

function placeCall(number)
{
    if (!webDialerLoggedIn) {
        console.warn('%c' + new Date().toISOString() + '  webdialerBG:placeCall, user not logged in.', 'color:darkgreen');        
        
        var options = {"type": "basic",  "title": chrome.i18n.getMessage('ExtensionName'), 
            "iconUrl": chrome.extension.getURL('images/icons/shoretel-logo-inverted.png'),
            "priority": 2,
            "message": chrome.i18n.getMessage('webdialerNotLoggedIn'),
            };

        var log = {
            'title': options.title,
            'message': options.message,
            'context': undefined,
            'buttons': undefined,
            'iconUrl': options.iconUrl
        }

        console.info(new Date().toISOString() + " Webdialer:Notification:Info Successfully created notification.", 'webdialerNotLoggedIn', JSON.stringify(log));
    
        chrome.notifications.create('webdialerNotLoggedIn', 
            options,
            notification);
    }
    
    else if (!webDialerConnected) {
        console.warn('%c' + new Date().toISOString() + '  webdialerBG:placeCall, no cas connection.', 'color:darkgreen');
        
        var options = {"type": "basic",  "title": chrome.i18n.getMessage('ExtensionName'), 
            "iconUrl": chrome.extension.getURL('images/icons/shoretel-logo-inverted.png'),
            "priority": 2,
            "message": chrome.i18n.getMessage('webdialerNotConnected'),
            "eventTime": Date.now() + 5000
            };

        var log = {
            'title': options.title,
            'message': options.message,
            'context': undefined,
            'buttons': undefined,
            'iconUrl': options.iconUrl
        }

        console.info(new Date().toISOString() + " Webdialer:Notification:Info Successfully created notification.", 'webdialerNotConnected', JSON.stringify(log));
    
        chrome.notifications.create('webdialerNotConnected', 
            options,
            notification);

    } else {
        let strippedNumber = number.replace(/[^\d\+]/g,"");
        console.debug('%c' + new Date().toISOString() + '  webdialerBG:placeCall, number: ' + strippedNumber + ', text: ' + number, 'color:darkgreen');
        shoretel.tel_makeCall(strippedNumber);          
    } 
}

function notification(noticationId) {
    setTimeout(function() {
        chrome.notifications.clear(noticationId, function(cleared) {
            console.info(new Date().toISOString() + " Webdialer:Notification:Info Notification cleared.", noticationId);
        });
    }, 5000);


}

function GetPreferences()
{
   var preferences = new Object();
   var option;

   // Country Code 
   preferences["countryCode"] = shoretel.dialingLocation ? shoretel.dialingLocation : 0;   
  
   // Web Dialer icons enabled
   preferences["enableLinks"] = booleanOption("enableLinks");

   return JSON.stringify(preferences, null);

}

function booleanOption(optionName)
{
   var option = localStorage[optionName];      
   if ((option == undefined) || ((option != "false") && (option != "true")))
   {            
      option = "true";
      localStorage[optionName] = option;
   }
   if (option == "true")
     return true;
   else
     return false;
}


function menuClick(info, tab)
{
   try
   { 
      if (contextMenu == undefined) {
          chrome.contextMenus.delete(info.menuItemId);
      }
      else {
          placeCall(info.selectionText);
      }
   }
   catch (e) {}
}

function menuError()
{
  var error;
  if (chrome.extension.lastError)
  {
     error = chrome.extension.lastError;
     alert(chrome.extension.lastError);
  }
}
// darkgreen


function updateContextMenu(item) {
    let time = new Date().toISOString();
    if (item.length == 0) { 
        if (contextMenu) { 
            chrome.contextMenus.remove(contextMenu);
            contextMenu = undefined;
            console.debug('%c' + time + '  webdialerBG: removed context menu.', 'color:darkgreen');
        }
    } else  {
        
        if (contextMenu) {
            chrome.contextMenus.update(contextMenu, {"title":  callLabel + item});
            console.debug('%c' + time + '  webdialerBG: updated context menu, '  + callLabel + item, 'color:darkgreen');
        } else {
            contextMenu = chrome.contextMenus.create({"title":  callLabel + item, "type": "normal", "contexts":["selection"], "onclick": menuClick});
            console.debug('%c' + time + '  webdialerBG: added context menu, '  + callLabel + item, 'color:darkgreen');
        }
    }
}


chrome.extension.onMessage.addListener(
    function(request, sender, sendResponse) {

        // verify this is our message
        if (request.cmd) {
        
            // save sender information
            menus = null;
            if (request.cmd == "preferences")
            {   
                sendResponse(GetPreferences());
            }
            else if (request.cmd == "contextMenu")
            {
                windowId = sender.tab.windowId;
                tabId = sender.tab.id;
                menus = request.menus;
                //chrome.contextMenus.removeAll(createContextMenus);
                updateContextMenu(menus[0]);
                sendResponse('');
            }
            else if (request.cmd == 'placeCall') {
                placeCall(request.number);
            }
        }
    }
); 


